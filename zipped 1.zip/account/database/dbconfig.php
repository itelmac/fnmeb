<?php
	$server_name = "localhost";
	$db_username = "root";
	$password = "";
	$db_name = "bank";
	$db_conn = new mysqli($server_name,$db_username,$password,$db_name);
?>
